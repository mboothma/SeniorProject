package com.marigrace.awstest;

import com.amazonaws.services.iot.client.AWSIotException;
import com.amazonaws.services.iot.client.AWSIotMessage;
import com.amazonaws.services.iot.client.AWSIotMqttClient;
import com.amazonaws.services.iot.client.AWSIotQos;
import com.amazonaws.services.iot.client.AWSIotTimeoutException;
import com.amazonaws.services.iot.client.AWSIotTopic;
import com.marigrace.awstest.SampleUtil.KeyStorePasswordPair;

/**
 * Hello world!
 *
 */

public class App {
	
	static class MyTopic extends AWSIotTopic {
        public MyTopic(String topic, AWSIotQos qos) {
            super(topic, qos);
        }

        @Override
        public void onMessage(AWSIotMessage message) {
            System.out.println(message.getStringPayload());
        }
    } 
	static class MyMessage extends AWSIotMessage {
        public MyMessage(String topic, AWSIotQos qos, String payload) {
            super(topic, qos, payload);
        }
        
        @Override
        public void onSuccess() {
            // called when message publishing succeeded
//            System.out.println("great success");
        }
        
        @Override
        public void onFailure() {
            // called when message publishing failed
            System.out.println("fail");
        }
        
        @Override
        public void onTimeout() {
            // called when message publishing timed out
            System.out.println("timed out");
        }
    } 


	public static void main(String[] args) throws AWSIotException, AWSIotTimeoutException {
		
		
		
		System.out.println("Hello World!");

		String clientEndpoint = "a1h3n7cpvfegiv.iot.us-east-1.amazonaws.com"; // replace <prefix> and <region> with your own
		String clientId = "arn:aws:iot:us-east-1:041420803039:thing/Marigrace_Laptop"; // replace with your own client ID. Use unique client IDs for concurrent
												// connections.
		String certificateFile = "C:\\Users\\i854340\\Desktop\\Marigrace_Laptop.cert.pem"; // X.509 based certificate file
		String privateKeyFile = "C:\\Users\\i854340\\Desktop\\Marigrace_Laptop.private.key"; // PKCS#1 or PKCS#8 PEM encoded private key file

		// SampleUtil.java and its dependency PrivateKeyReader.java can be copied from
		// the sample source code.
		// Alternatively, you could load key store directly from a file - see the
		// example included in this README.
		KeyStorePasswordPair pair = SampleUtil.getKeyStorePasswordPair(certificateFile, privateKeyFile);
		AWSIotMqttClient client = new AWSIotMqttClient(clientEndpoint, clientId, pair.keyStore, pair.keyPassword);
		
        client = new AWSIotMqttClient(clientEndpoint, clientId, pair.keyStore, pair.keyPassword);
		
		// optional parameters can be set before connect()
		client.connect(6000);
		
		AWSIotQos qos = AWSIotQos.QOS0;
        long timeout = 3000;
        
        
        MyMessage message = new MyMessage("iotbutton/G030MD0315248H4D", qos, "hey there");
        client.publish(message, timeout); 
        

        MyTopic topic = new MyTopic("iotbutton/G030MD0315248H4D", qos);
        client.subscribe(topic);
	}
}
